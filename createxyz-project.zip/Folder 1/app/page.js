"use client";
import React from "react";

function MainComponent() {
  const [timeLeft, setTimeLeft] = React.useState({
    days: 31,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });
  const [showForm, setShowForm] = React.useState(false);
  const [formData, setFormData] = React.useState({ name: "", email: "" });
  const [successMessage, setSuccessMessage] = React.useState("");
  const [showGoogleForm, setShowGoogleForm] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    const getTargetDate = () => {
      const storedDate = localStorage.getItem("targetDate");
      if (storedDate) {
        return new Date(storedDate);
      } else {
        const currentDate = new Date();
        const newTargetDate = new Date(currentDate);
        newTargetDate.setDate(currentDate.getDate() + 31);
        localStorage.setItem("targetDate", newTargetDate);
        return newTargetDate;
      }
    };

    const targetDate = getTargetDate();

    const interval = setInterval(() => {
      const currentDate = new Date();
      const timeDifference = targetDate - currentDate;

      if (timeDifference <= 0) {
        const newTargetDate = new Date();
        newTargetDate.setDate(newTargetDate.getDate() + 31);
        localStorage.setItem("targetDate", newTargetDate);
        setTimeLeft({ days: 31, hours: 0, minutes: 0, seconds: 0 });
      } else {
        const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
        const hours = Math.floor(
          (timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
        );
        const minutes = Math.floor(
          (timeDifference % (1000 * 60 * 60)) / (1000 * 60)
        );
        const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);

        setTimeLeft({ days, hours, minutes, seconds });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("https://zanyai-api.onrender.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });
      if (!response.ok) {
        throw new Error("Failed to send email");
      }
      await fetch("/api/send-notification-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });
      setSuccessMessage(
        "Thank you! You'll be notified once GhanaStay is launched!"
      );
      setShowForm(false);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <head>
        <meta
          name="keywords"
          content="GhanaStay, luxury accommodations in Ghana, hotel booking service"
        />
      </head>
      <div
        className="relative h-screen bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://ucarecdn.com/b6e5dfbf-cf48-46f9-80dd-4099371516e3/-/format/auto/')",
        }}
      >
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center text-white">
          <nav className="absolute top-0 left-0 right-0 flex justify-center py-4">
            <div className="text-2xl font-bold font-inter">
              <span className="text-white">Ghana</span>
              <span className="text-[#FFD700]">Stay</span>
            </div>
          </nav>
          <h1 className="text-4xl md:text-6xl font-bold font-inter text-gray-900 dark:text-white">
            Your Perfect Stay in Ghana
          </h1>
          <div className="mt-2 text-2xl md:text-4xl font-bold font-inter text-gray-900 dark:text-white glow-effect">
            Coming Soon!
          </div>
          <p className="mt-4 text-sm md:text-md font-inter text-gray-700 dark:text-gray-300">
            Skip the stress of searching. Tell us what you need, and we’ll find
            the best hotel or apartment for you – no extra charges, just great
            deals!
          </p>
          <div className="mt-6 text-lg font-bold font-inter text-gray-900 dark:text-white">
            Launching in {timeLeft.days} days, {timeLeft.hours} hours,{" "}
            {timeLeft.minutes} minutes, and {timeLeft.seconds} seconds!
          </div>
          <div className="mt-8 flex space-x-4">
            <button
              onClick={() => setShowForm(true)}
              className="px-6 py-3 bg-gray-900 text-white font-inter rounded-md hover:bg-gray-700 transition duration-300 ease-in-out"
            >
              Notify Me
            </button>
            <button
              onClick={() => setShowGoogleForm(true)}
              className="px-6 py-3 bg-gray-900 text-white font-inter rounded-md hover:bg-gray-700 transition duration-300 ease-in-out"
            >
              Submit Requests
            </button>
          </div>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-20">
          <div className="bg-white p-6 rounded-md shadow-md relative">
            <button
              onClick={() => setShowForm(false)}
              className="absolute top-2 right-2 text-gray-700 hover:text-gray-900"
            >
              &times;
            </button>
            <h2 className="text-xl font-bold font-inter text-gray-900 mb-4">
              Notify Me
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label
                  className="block text-gray-700 font-inter mb-2"
                  htmlFor="name"
                >
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label
                  className="block text-gray-700 font-inter mb-2"
                  htmlFor="email"
                >
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full px-4 py-2 bg-blue-600 text-white font-inter rounded-md hover:bg-blue-500 transition duration-300 ease-in-out"
                disabled={loading}
              >
                {loading ? "Submitting..." : "Submit"}
              </button>
            </form>
          </div>
        </div>
      )}

      {showGoogleForm && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-20">
          <div className="bg-white p-6 rounded-md shadow-md relative">
            <button
              onClick={() => setShowGoogleForm(false)}
              className="absolute top-2 right-2 text-gray-700 hover:text-gray-900"
            >
              &times;
            </button>
            <iframe
              src="https://docs.google.com/forms/d/e/1FAIpQLSdBSP-FUmCedAw4-GGtLJ5zK--TNbzxPbBKjvcKox8QXzS-dQ/viewform?embedded=true"
              className="w-full h-[80vh] md:w-[640px] md:h-[80vh]"
              frameBorder="0"
              marginHeight="0"
              marginWidth="0"
            >
              Loading…
            </iframe>
          </div>
        </div>
      )}

      {successMessage && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-md shadow-md">
            <p className="text-lg font-inter text-gray-900">{successMessage}</p>
            <button
              onClick={() => setSuccessMessage("")}
              className="mt-4 px-4 py-2 bg-blue-600 text-white font-inter rounded-md hover:bg-blue-500 transition duration-300 ease-in-out"
            >
              Close
            </button>
          </div>
        </div>
      )}

      <div className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold font-inter text-gray-900 text-center">
            <span className="bg-black px-2">
              <span className="text-white">Ghana</span>
              <span className="text-[#FFD700]">Stay</span>
            </span>
          </h2>
          <h3 className="mt-4 text-xl font-bold font-inter text-gray-700 text-center">
            What is GhanaStay?
          </h3>
          <p className="mt-2 text-md font-inter text-gray-600 text-center">
            GhanaStay is a modern platform designed to make finding the perfect
            accommodation in Ghana effortless. Whether you're a traveler or a
            local, we handle the search and booking process for you, ensuring
            you get the best deals without the hassle.
          </p>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl text-gray-900">
                <i className="fas fa-user-plus"></i>
              </div>
              <h4 className="mt-2 text-lg font-bold font-inter text-gray-700">
                Sign Up
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                Join GhanaStay and let us handle your accommodation needs.
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl text-gray-900">
                <i className="fas fa-star"></i>
              </div>
              <h4 className="mt-2 text-lg font-bold font-inter text-gray-700">
                Become a Premium Member
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                For just $50/year, request bookings anytime with no hidden fees!
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl text-gray-900">
                <i className="fas fa-paper-plane"></i>
              </div>
              <h4 className="mt-2 text-lg font-bold font-inter text-gray-700">
                Submit Your Request
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                Tell us what you’re looking for, and we’ll find the best options
                for you.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold font-inter text-gray-900">
            Be the First to Experience GhanaStay!
          </h2>
          <p className="mt-4 text-md font-inter text-gray-600">
            We’re launching soon, and you can already submit your accommodation
            requests. Click the button below to proceed and let us know what
            you’re looking for.
          </p>
          <button
            onClick={() => setShowGoogleForm(true)}
            className="mt-6 inline-block px-8 py-4 bg-blue-600 text-white font-inter rounded-md hover:bg-blue-500 transition duration-300 ease-in-out"
          >
            Submit Your Request Now
          </button>
        </div>
      </div>

      <div className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold font-inter text-gray-900 text-center">
            What You Get As Premium Member
          </h2>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl text-gray-900 mb-2">
                <i className="fas fa-car"></i>
              </div>
              <h4 className="text-lg font-bold font-inter text-gray-700">
                Free Pickups
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                Partnered with Uber and Bolt to provide free pickups in Accra & Kumasi,
                including the airport, on your first booking request in Kumasi/Accra of every year.
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl text-gray-900 mb-2">
                <i className="fas fa-tags"></i>
              </div>
              <h4 className="text-lg font-bold font-inter text-gray-700">
                Exclusive Discounts
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                Discounts from $10 to $200 per booking with top hotels,
                apartments, and hostels.
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl text-gray-900 mb-2">
                <i className="fas fa-money-bill-wave"></i>
              </div>
              <h4 className="text-lg font-bold font-inter text-gray-700">
                No Hidden Fees
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                No additional fees unless you request for our escrow payment service which we secure your money. Payments are release after you settle in safely to ensure security.
                You may also choose to pay after settling in to ensure security.
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl text-gray-900 mb-2">
                <i className="fas fa-headset"></i>
              </div>
              <h4 className="text-lg font-bold font-inter text-gray-700">
                24/7 Support
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                Dedicated support team available around the clock for
                assistance.
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl text-gray-900 mb-2">
                <i className="fas fa-infinity"></i>
              </div>
              <h4 className="text-lg font-bold font-inter text-gray-700">
                Unlimited Booking Requests
              </h4>
              <p className="mt-1 text-md font-inter text-gray-600">
                Send unlimited booking requests throughout the year for free.
                You don't need a credit card! No extra charges, just great
                deals.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-100 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm font-inter text-gray-600">
            Questions? Email us at{" "}
            <a
              href="mailto:info@ghanastay.co"
              className="text-blue-600 hover:underline"
            >
              info@ghanastay.co
            </a>{" "}
            or message us on WhatsApp at +233 53 942 8718.
          </p>
          <p className="mt-2 text-sm font-inter text-gray-600">
            GhanaStay is launching soon. Stay tuned!
          </p>
        </div>
      </div>

      <style jsx global>{`
        .glow-effect {
          text-shadow: 0 0 10px rgba(255, 255, 255, 0.8),
            0 0 20px rgba(255, 255, 255, 0.6);
        }
        .fade-in {
          animation: fadeIn 2s ease-in-out;
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;